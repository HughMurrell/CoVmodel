# load packages
println("loading packages ...")
using StatsBase, Distributions, Plots, DataFrames, CSV, Dates, HTTP, Impute, DSP;

# some model parameters that will be used throughout this notebook
IFP = 7   # infectious period in days
GAMMA = 1/IFP  # recovery rate
SMOOTHING_PASSES = 3 # number of times to apply moving average filter to case data
INF_CUTOFF = 0.02 # to detect when epidemic is over
ONSET_DELAY = 4  # default onset delayin days, might get changed later
println("IFP=",IFP," GAMMA=",GAMMA," SMOOTHING_PASSES=",
    SMOOTHING_PASSES," INF_CUTOFF=",INF_CUTOFF," ONSET_DELAY=",ONSET_DELAY)

# set the output url for saving data and plots
# directories called data and plots must exist at this location
output_url = "./RtLive/"

# load the dataset and pick out Upper tier plus national data
url="https://coronavirus.data.gov.uk/downloads/csv/coronavirus-cases_latest.csv"
full_data = CSV.read(IOBuffer(HTTP.get(url).body))
println(names(full_data))
data=DataFrame(full_data[:,1:5])
rename!(data,Symbol.(["location","code","type","date","new_cases"]))
println("table read, size = ",size(data))
# date = Symbol("Specimen date")
println("latest counts on ",maximum(data[:,:date]))
println(union(data[:,:type]))
println(sort(union(data[data[:,:type].=="Upper tier local authority",:location])))
data = vcat( data[data[:,:type].=="Upper tier local authority",:], data[data[:,:type].=="Nation",:] )
println("data loaded size = ",size(data))

# create Weibull filter and helper ftns for adjusting for reporting delay
adj_range = collect(1:1:30)
p_delay = [pdf.(Weibull(2, 5),t) for t in adj_range]
p_delay = p_delay ./ sum(p_delay)

function estimate_onset(new_cases, p_delay)
    return reverse(conv(reverse(new_cases),p_delay))[length(p_delay):end]
end

function adjust_onset(onset, p_delay)
    c_delay = cumsum(p_delay)
    extras = length(onset) - length(c_delay)
    if (extras > 0)
        cd = vcat(c_delay,ones(extras))
        adjusted = onset ./ reverse(cd)
    else
        adjusted = onset
    end
    return adjusted[1:end]
end

function moving_average(inf; alpha=0.5)
    vs = inf
    if length(vs) > 1
        ret = 
            # vcat( vs[1], [ alpha * vs[i] + (1 - alpha)*vs[i-1] for i = 2:length(vs) ] )
            vcat((vs[1]+2*vs[1])/3,
                   [sum(@view vs[i:(i+2)])/3 for i in 1:(length(vs)-(2))],
                    (2*vs[length(vs)]+vs[length(vs)])/3)
    else
        ret = vs
    end
    return ret
    return Int64.(round.(ret))
end

# function to compute size of infectious pool from adjusted case counts
function compute_infectives(new_cases) 
    onset = estimate_onset(new_cases,p_delay)
    adj_onset = adjust_onset(onset,p_delay)
    if length(adj_onset) >= IFP
       infects = [sum(adj_onset[i-IFP+1:i])
                        for i in IFP:length(adj_onset) ] 
    else
        infects = []
    end
    return infects
end

# function to process data from a single location (ie one time series)
function process_data(data)
    nz = copy(data[data[:,:date] .> Date(2020,2,23),:])
    sort!(nz,:date)
    nz[ismissing.(nz[:,:new_cases]),:new_cases] .= 0
    nz[:,:cases] = Float64.(cumsum(nz[:,:new_cases])) 
    allowmissing!(nz)
    # now insert missing dates and impute cumulative cases for those dates
    if size(nz)[1] > 1
        dr = nz[1,:date]:Day(1):nz[end,:date]
        for d in dr
            if ! (d in nz[:,:date])
                push!(nz,[missing for i in 1:size(nz)[2]])
                nz[end,:location] = nz[end-1,:location]
                nz[end,:date] = d
            end
        end
        sort!(nz,:date)
        nz[!,:cases] = Impute.interp(nz[:,:cases])
    end
    smooth_new_cases = diff(nz[:,:cases])
    for i in 1:SMOOTHING_PASSES
        smooth_new_cases = moving_average(smooth_new_cases)
    end
    # nz[:,:new_cases] = Int64.(round.(smooth_new_cases))
    infectives = compute_infectives(smooth_new_cases)
    nz = nz[IFP+1:end,:]
    nz[:,:infectives] = Float64.(infectives)
    return nz   
end 

function strip_leading_zero_case_counts(data)
    nz = copy(data)
    nc = nz[:,:new_cases]
    ind = 1
    while (ind <= length(nc) && nc[ind]==0)
        ind+=1
    end
    if (ind != 1)
        nz = copy(nz[ind:end,:])
    end
    return(nz)
end

# function to extract data from one location, strip zeros and process
function prepare_cases(full_data, country)
    country_data = full_data[full_data[:,:location].==country,:]
    country_data = strip_leading_zero_case_counts(country_data)
    if size(country_data)[1] < 30  # need at least one month of case counts
        return (country_data, false)
    end
    country_data_filtered = process_data(country_data)
    sanity_check=true
    if (ismissing(minimum(country_data_filtered[:,:infectives])) ||
        minimum(country_data_filtered[:,:infectives])< 0)
        sanity_check = false
    end
    return (country_data_filtered, sanity_check)
end

# function to estimate Rt from It for data from a single location that has already been pre-processed.
function estimate_rt(data)
    infectives = data[:,:infectives]
    # instantaneous Rt estimate
    rt_est = [ 1 + IFP * ((infectives[i+1]-infectives[i])/(infectives[i])) 
                            for i in 1:length(infectives)-1]
    # apply low Rt cutoff 
    for i in 1:length(rt_est)
        max_inf = maximum(infectives[1:i])
        if (( infectives[i]/max_inf < INF_CUTOFF ) || rt_est[i]<0 )
            rt_est[i] = 0
        end
    end
    # sanity check
    sane = true
    last_week = rt_est[end-6:end]
    if maximum(last_week)-minimum(last_week) > 2
        sane = false
        println("something fishy...")
    end
    data = data[1:end-1,:]
    data[!,:rt_est] = rt_est
    # throw away the last ONSET_DELAY data
    data = data[1:end-ONSET_DELAY+1,:]
    return (data,sane)
end     

# the rest of the script loops through each location in the data set
# calculates Rt and It values at each date, produces plots of them
# saves the plots, gathers the data and at the end creates a static
# ranking plot and outputs the ranking data as a csv for dynamic display

countries = sort(unique(data[:,:location]))
df = DataFrame(country=String[], start_date=Date[],end_date=Date[], est_date=Date[],
                    rt=Float64[],irat=Float64[],rank=Float64[])
for country in countries
    dc,sane = prepare_cases(data,country)
    if ( ! sane ) 
        println("skipping $country ... sanity check is $sane")
    else
        infectives = dc[:,:infectives]
        if ( length(infectives)<10 || maximum(infectives) < 100)
            println("skipping $country ... not enough data")
        else
            println("processing $country ...")
            start_date = dc[1,:date]  
            end_date = dc[end,:date]
            # calculate ratio of last I(t) to maximum of all I(t)s
            irat = round(infectives[end]/maximum(infectives),digits=2)
            inf_score = Int64(round(
                    100*(infectives[end]-infectives[end-ONSET_DELAY])/infectives[end-ONSET_DELAY],
                digits=0))
            up_down=""
            if inf_score > 0
                up_down = "up"
            else
                up_down = "down"
                inf_score = - inf_score
            end
            fig = plot(dc[:,:date], [dc[:,:infectives], dc[:,:new_cases]], lw=6,
                    legend=:topleft,
                    label=[ "infectious" "new_cases" ],
                    title="$country, infectious pool $inf_score% $up_down by $end_date")
            savefig(output_url*"plots/Inf_$country")
        
            # now use helpter to compute rt estimates
            dc,sane = estimate_rt(dc)
            if (! sane)
                println("skipping $country ... Rt estimation failed")
            else
                est_date = dc[end,:date]
                # make an Rt plot for this country
                rt_score = round(sum(dc[end,:rt_est]),digits=2)
            # cdf = DataFrame(date = dates[2:end], rt = rt_est)
                fig = plot(dc[:,:date], dc[:,:rt_est], 
                        lw = 3, label = "Rt estimate",
                        m=:circle, ms=6, ylimits=[-0.5,5.5],
                        title="$country, R(t) = $rt_score at $est_date")
                plot!(dc[:,:date], ones(size(dc)[1]),lw=3,label="R(t)=1")
                savefig(output_url*"plots/Rt_$country")
                # now save last mlrt, low, high, irat and rank
                rank = round(rt_score * irat, digits=2)
                push!(df,[country start_date end_date est_date rt_score irat rank])
            end
        end
    end
end

# save the Rt scores as a csv files 
dft = df
sort!(dft,:country)
CSV.write(output_url*"data/ranking_alpha.csv",dft)
sort!(dft,:rank)
CSV.write(output_url*"data/ranking_rtirat.csv",dft)
sort!(dft,:rt)
CSV.write(output_url*"data/ranking_rt.csv",dft)

println("latest date =", maximum(dft[:,:end_date]))

# static ranking plot
Plots.Font("sans-serif", 10, :hcenter, :center, 0.0, RGB(0.0,0.0,0.0))
myfont = text("").font
myfont.rotation = 90
end_date = maximum(dft[:,:end_date])
fig = plot()
plot!(ones(size(dft)[1]),label="",c=2, lw=3,    
    title="R(t) ranking - as of $end_date")
scatter!(dft[:,:rt],markershape=:circle,   
    markersize = 8, c=1, 
    ylims=[-1, 4], yticks = [0.0, 1.0, 2.0, 3.0], xticks = [],
    # series_annotations=text.(dft[:,:country], :middle, 6, :hcenter, :vcenter),
    size=(2400,400),
    label="rank", legend=:topleft)
for j in 1:size(dft)[1]
    annotate!(j,dft[:,:rt][j]+1, dft[:,:country][j], myfont)
end
savefig(output_url*"plots/ranking")


