
To run the script install Julia and execute:

Julia rt.jl

from the command prompt.

The first time you do this you will get missing package errors.
to install a package do the following

run Julia from the command line to start the Julia REPL
and get the julia prompt

julia>

type ]    (close square brackets) to get to the package manager prompt

pkg>

type add package_name to add each package. for example for DSP package type

pkg> add DSP

and then wait whilst DSP is added.

once all the packages listed on the first line of the script are added 
the script will run to the end and store output in the RtLive directory

to view the output with the gui cd to RtLive and run a simple python web server

python -m SimpleHTTPServer 8000

and then point your web browser to 

http://localhost:8000/

good luck 
